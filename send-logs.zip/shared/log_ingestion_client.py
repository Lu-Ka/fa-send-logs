"""
Client pour ingérer des logs dans Log Analytics destination via DCE/DCR
"""

import logging
from typing import List, Dict, Any
from azure.identity import AzureAuthorityHosts, DefaultAzureCredential
from azure.monitor.ingestion import LogsIngestionClient
from azure.core.exceptions import HttpResponseError
from tenacity import retry, stop_after_attempt, wait_exponential


class LogIngestionClient:
    """Client pour ingérer des logs via Data Collection Endpoint"""

    def __init__(self, config):
        """
        Initialise le client d'ingestion

        Args:
            config: Instance de Config
        """
        self.logger = logging.getLogger(__name__)
        self.config = config

        # Utiliser Managed Identity pour l'authentification
        credential = DefaultAzureCredential(authority=AzureAuthorityHosts.AZURE_CHINA)

        # Créer le client d'ingestion
        self.client = LogsIngestionClient(
            endpoint=config.dce_endpoint, credential=credential, logging_enable=True
        )

        self.dcr_immutable_id = config.dcr_immutable_id
        self.stream_name = config.dcr_stream_name

        self.logger.info(f"Client d'ingestion initialisé - DCE: {config.dce_endpoint}")

    @retry(
        stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=2, max=10)
    )
    def send_logs(self, logs: List[Dict[str, Any]]) -> bool:
        """
        Envoie un batch de logs au DCE

        Args:
            logs: Liste de dictionnaires contenant les logs

        Returns:
            True si l'ingestion est réussie
        """
        if not logs:
            self.logger.warning("Aucun log à envoyer")
            return True

        try:
            self.logger.info(f"Envoi de {len(logs)} logs au DCE")

            # Préparer les logs pour l'ingestion
            prepared_logs = self._prepare_logs(logs)

            # Envoyer les logs
            self.client.upload(
                rule_id=self.dcr_immutable_id,
                stream_name=self.stream_name,
                logs=prepared_logs,
            )

            self.logger.info(f"Ingestion réussie: {len(logs)} logs envoyés")
            return True

        except HttpResponseError as e:
            self.logger.error(
                f"Erreur HTTP lors de l'ingestion: {e.status_code} - {e.message}"
            )
            raise
        except Exception as e:
            self.logger.error(f"Erreur lors de l'ingestion: {str(e)}")
            raise

    def _prepare_logs(self, logs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Prépare les logs pour l'ingestion (transformation si nécessaire)

        Args:
            logs: Logs bruts depuis Log Analytics source

        Returns:
            Logs formatés pour le DCR
        """
        prepared = []

        for log in logs:
            # Créer une copie pour ne pas modifier l'original
            prepared_log = log.copy()

            # Ajouter TimeGenerated si absent (requis par DCR)
            if "TimeGenerated" not in prepared_log:
                from datetime import datetime

                prepared_log["TimeGenerated"] = datetime.utcnow().isoformat()

            # Supprimer les champs système qui ne doivent pas être réingérés
            fields_to_remove = ["_ResourceId", "Type", "TenantId", "_SubscriptionId"]
            for field in fields_to_remove:
                prepared_log.pop(field, None)

            prepared.append(prepared_log)

        return prepared

    def send_logs_in_batches(
        self, logs: List[Dict[str, Any]], batch_size: int = 1000
    ) -> int:
        """
        Envoie les logs par batches pour éviter les timeouts

        Args:
            logs: Liste complète des logs
            batch_size: Taille de chaque batch

        Returns:
            Nombre total de logs envoyés avec succès
        """
        total_sent = 0
        total_logs = len(logs)

        self.logger.info(f"Envoi de {total_logs} logs en batches de {batch_size}")

        for i in range(0, total_logs, batch_size):
            batch = logs[i : i + batch_size]
            try:
                if self.send_logs(batch):
                    total_sent += len(batch)
                    self.logger.info(
                        f"Progression: {total_sent}/{total_logs} logs envoyés"
                    )
            except Exception as e:
                self.logger.error(f"Échec du batch {i // batch_size + 1}: {str(e)}")
                # Continuer avec le prochain batch
                continue

        self.logger.info(f"Ingestion terminée: {total_sent}/{total_logs} logs envoyés")
        return total_sent
