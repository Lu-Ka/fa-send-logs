"""
Gestionnaire de checkpoint pour suivre la progression du traitement
"""

import logging
from datetime import datetime, timedelta
from typing import Optional
from azure.data.tables import TableServiceClient
from azure.core.exceptions import ResourceNotFoundError
from azure.identity import AzureAuthorityHosts, DefaultAzureCredential


class CheckpointManager:
    """Gère les checkpoints dans Azure Table Storage"""

    def __init__(self, config):
        """
        Initialise le gestionnaire de checkpoint

        Args:
            config: Instance de Config
        """
        self.logger = logging.getLogger(__name__)
        self.config = config

        # Créer le client Table Storage
        self.table_service = TableServiceClient(
            credentials=DefaultAzureCredential(
                authority=AzureAuthorityHosts.AZURE_CHINA
            )
        )

        self.table_name = config.checkpoint_table_name

        # Créer la table si elle n'existe pas
        try:
            self.table_client = self.table_service.create_table_if_not_exists(
                self.table_name
            )
            self.logger.info(f"Table de checkpoint '{self.table_name}' prête")
        except Exception as e:
            self.logger.error(f"Erreur lors de la création de la table: {str(e)}")
            raise

    def get_last_checkpoint(self) -> datetime:
        """
        Récupère le dernier timestamp traité

        Returns:
            Datetime du dernier checkpoint, ou datetime actuel - 1h si aucun checkpoint
        """
        try:
            entity = self.table_client.get_entity(
                partition_key="checkpoint", row_key="last_processed"
            )

            timestamp_str = entity.get("timestamp")
            if timestamp_str:
                checkpoint_time = datetime.fromisoformat(timestamp_str)
                self.logger.info(f"Checkpoint trouvé: {checkpoint_time.isoformat()}")
                return checkpoint_time
            else:
                self.logger.warning("Checkpoint trouvé mais timestamp manquant")
                return self._get_default_checkpoint()

        except ResourceNotFoundError:
            self.logger.info("Aucun checkpoint trouvé, utilisation du défaut")
            return self._get_default_checkpoint()
        except Exception as e:
            self.logger.error(f"Erreur lors de la lecture du checkpoint: {str(e)}")
            return self._get_default_checkpoint()

    def _get_default_checkpoint(self) -> datetime:
        """
        Retourne le checkpoint par défaut (maintenant - 1 heure)

        Returns:
            Datetime par défaut
        """
        default_time = datetime.utcnow() - timedelta(hours=1)
        self.logger.info(
            f"Utilisation du checkpoint par défaut: {default_time.isoformat()}"
        )
        return default_time

    def update_checkpoint(
        self,
        timestamp: datetime,
        records_processed: int,
        status: str = "success",
        error_message: Optional[str] = None,
    ) -> bool:
        """
        Met à jour le checkpoint avec les informations de traitement

        Args:
            timestamp: Nouveau timestamp à sauvegarder
            records_processed: Nombre de logs traités
            status: Statut de l'exécution ('success' ou 'error')
            error_message: Message d'erreur si applicable

        Returns:
            True si la mise à jour est réussie
        """
        try:
            entity = {
                "PartitionKey": "checkpoint",
                "RowKey": "last_processed",
                "timestamp": timestamp.isoformat(),
                "records_processed": records_processed,
                "last_update": datetime.utcnow().isoformat(),
                "status": status,
            }

            if error_message:
                entity["error_message"] = error_message

            self.table_client.upsert_entity(entity)
            self.logger.info(
                f"Checkpoint mis à jour: {timestamp.isoformat()} "
                f"({records_processed} logs, status: {status})"
            )
            return True

        except Exception as e:
            self.logger.error(f"Erreur lors de la mise à jour du checkpoint: {str(e)}")
            return False

    def get_checkpoint_history(self, limit: int = 10) -> list:
        """
        Récupère l'historique des checkpoints

        Args:
            limit: Nombre maximum d'entrées à retourner

        Returns:
            Liste des derniers checkpoints
        """
        try:
            entities = self.table_client.query_entities(
                query_filter="PartitionKey eq 'checkpoint'",
                select=["timestamp", "records_processed", "status", "last_update"],
            )

            history = list(entities)[:limit]
            self.logger.info(f"Historique récupéré: {len(history)} entrées")
            return history

        except Exception as e:
            self.logger.error(
                f"Erreur lors de la récupération de l'historique: {str(e)}"
            )
            return []
