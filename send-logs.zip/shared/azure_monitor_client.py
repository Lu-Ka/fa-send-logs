"""
Client pour interroger Azure Monitor Log Analytics dans le tenant source
"""

import logging
from datetime import datetime
from typing import List, Dict, Any
from azure.identity import ClientSecretCredential
from azure.monitor.query import LogsQueryClient, LogsQueryStatus
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type,
)


class AzureMonitorClient:
    """Client pour interroger Log Analytics dans le tenant source"""

    def __init__(self, config):
        """
        Initialise le client Azure Monitor

        Args:
            config: Instance de Config contenant les credentials
        """
        self.logger = logging.getLogger(__name__)
        self.config = config

        # Créer credential pour le tenant source
        self.credential = ClientSecretCredential(
            tenant_id=config.source_tenant_id,
            client_id=config.source_client_id,
            client_secret=config.source_client_secret,
        )

        # Créer le client de requête
        self.client = LogsQueryClient(self.credential)
        self.workspace_id = config.source_workspace_id

        self.logger.info(
            f"Client Azure Monitor initialisé pour workspace {self.workspace_id}"
        )

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        retry=retry_if_exception_type(Exception),
    )
    def query_logs(self, kql_query: str, timespan: str = None) -> List[Dict[str, Any]]:
        """
        Exécute une requête KQL sur Log Analytics

        Args:
            kql_query: Requête KQL à exécuter
            timespan: Période de temps (optionnel)

        Returns:
            Liste de dictionnaires contenant les logs
        """
        try:
            self.logger.info(
                f"Exécution de la requête KQL sur workspace {self.workspace_id}"
            )
            self.logger.debug(f"Requête: {kql_query[:200]}...")

            # Exécuter la requête
            response = self.client.query_workspace(
                workspace_id=self.workspace_id, query=kql_query, timespan=timespan
            )

            # Vérifier le statut
            if response.status == LogsQueryStatus.SUCCESS:
                # Convertir les résultats en liste de dictionnaires
                results = []
                if response.tables:
                    table = response.tables[0]
                    columns = [col.name for col in table.columns]

                    for row in table.rows:
                        log_entry = {}
                        for i, value in enumerate(row):
                            # Convertir les datetime en ISO format
                            if isinstance(value, datetime):
                                log_entry[columns[i]] = value.isoformat()
                            else:
                                log_entry[columns[i]] = value
                        results.append(log_entry)

                self.logger.info(f"Requête réussie: {len(results)} logs récupérés")
                return results

            elif response.status == LogsQueryStatus.PARTIAL:
                self.logger.warning(
                    f"Requête partiellement réussie: {response.partial_error}"
                )
                # Retourner les résultats partiels
                results = []
                if response.partial_data and response.partial_data[0].tables:
                    table = response.partial_data[0].tables[0]
                    columns = [col.name for col in table.columns]
                    for row in table.rows:
                        log_entry = dict(zip(columns, row))
                        results.append(log_entry)
                return results

            else:
                error_msg = f"Échec de la requête: {response.status}"
                self.logger.error(error_msg)
                raise Exception(error_msg)

        except Exception as e:
            self.logger.error(f"Erreur lors de l'exécution de la requête: {str(e)}")
            raise

    def test_connection(self) -> bool:
        """
        Teste la connexion au workspace Log Analytics

        Returns:
            True si la connexion est réussie
        """
        try:
            test_query = "NetworkLogs_CL | take 1"
            self.query_logs(test_query)
            self.logger.info("Test de connexion réussi")
            return True
        except Exception as e:
            self.logger.error(f"Test de connexion échoué: {str(e)}")
            return False
