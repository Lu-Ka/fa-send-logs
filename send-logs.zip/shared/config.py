"""
Configuration centralisée pour la Function App
Récupère les secrets depuis Key Vault via Managed Identity
"""

import os
import logging
from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient


class Config:
    """Classe de configuration pour gérer tous les paramètres"""

    def __init__(self):
        """Initialise la configuration et récupère les secrets"""
        self.logger = logging.getLogger(__name__)

        # Credential pour Managed Identity
        self.credential = DefaultAzureCredential()

        # Key Vault
        kv_name = os.environ.get("KEY_VAULT_NAME")
        if not kv_name:
            raise ValueError("KEY_VAULT_NAME environment variable is required")

        kv_uri = f"https://{kv_name}.vault.azure.cn"
        self.logger.info(f"Connexion au Key Vault: {kv_uri}")

        try:
            self.kv_client = SecretClient(vault_url=kv_uri, credential=self.credential)

            # Récupérer les secrets du tenant source
            self.source_tenant_id = self._get_secret("SourceTenantId")
            self.source_client_id = self._get_secret("SourceClientId")
            self.source_client_secret = self._get_secret("SourceClientSecret")
            self.source_workspace_id = self._get_secret("SourceWorkspaceId")

            self.logger.info("Secrets récupérés avec succès depuis Key Vault")

        except Exception as e:
            self.logger.error(f"Erreur lors de la récupération des secrets: {str(e)}")
            raise

        # Configuration destination (variables d'environnement)
        self.dce_endpoint = os.environ.get("DCE_ENDPOINT")
        self.dcr_immutable_id = os.environ.get("DCR_IMMUTABLE_ID")
        self.dcr_stream_name = os.environ.get("DCR_STREAM_NAME")

        if not self.dce_endpoint or not self.dcr_immutable_id:
            raise ValueError("DCE_ENDPOINT and DCR_IMMUTABLE_ID are required")

        # Storage pour checkpoint
        self.checkpoint_table_name = "LogForwarderCheckpoint"

        # Configuration de traitement
        self.batch_size = int(os.environ.get("BATCH_SIZE", "5000"))
        self.max_retries = int(os.environ.get("MAX_RETRIES", "3"))

        self.logger.info(f"Configuration initialisée - Batch size: {self.batch_size}")

    def _get_secret(self, secret_name: str) -> str:
        """Récupère un secret depuis Key Vault"""
        try:
            secret = self.kv_client.get_secret(secret_name)
            return secret.value
        except Exception as e:
            self.logger.error(
                f"Erreur lors de la récupération du secret {secret_name}: {str(e)}"
            )
            raise
