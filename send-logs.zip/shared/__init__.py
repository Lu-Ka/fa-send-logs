# Shared modules for the log forwarder function
