"""
Azure Function principale - Timer Trigger pour le transfert de logs
"""

import azure.functions as func
import logging
from datetime import datetime
import traceback

# Importer les modules partagés
from shared.config import Config
from shared.azure_monitor_client import AzureMonitorClient
from shared.log_ingestion_client import LogIngestionClient
from shared.checkpoint_manager import CheckpointManager


app = func.FunctionApp()


@app.function_name(name="NetworkLogs")
@app.timer_trigger(
    schedule="0 */15 * * * *",
    arg_name="myTimer",
    run_on_startup=False,
    use_monitor=False,
)
def main(mytimer: func.TimerRequest) -> None:
    """
    Fonction principale déclenchée par le timer

    Args:
        mytimer: Objet timer contenant les informations de déclenchement
    """
    # Configuration du logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    utc_timestamp = datetime.utcnow().isoformat()

    if mytimer.past_due:
        logger.warning("Le timer est en retard!")

    logger.info(f"=== Démarrage du transfert de logs à {utc_timestamp} ===")

    try:
        # 1. Initialiser la configuration
        logger.info("Initialisation de la configuration...")
        config = Config()

        # 2. Initialiser les clients
        logger.info("Initialisation des clients...")
        checkpoint_mgr = CheckpointManager(config)
        source_client = AzureMonitorClient(config)
        dest_client = LogIngestionClient(config)

        # 3. Récupérer le dernier checkpoint
        last_checkpoint = checkpoint_mgr.get_last_checkpoint()
        current_time = datetime.utcnow()

        logger.info(
            f"Période de traitement: {last_checkpoint.isoformat()} "
            f"à {current_time.isoformat()}"
        )

        # 4. Construire la requête KQL
        kql_query = f"""
        NetworkLogs_CL
        | where Computer startswith "CN"
        | where TimeGenerated > datetime({last_checkpoint.isoformat()})
        | where TimeGenerated <= datetime({current_time.isoformat()})
        | order by TimeGenerated asc
        """

        logger.info("Exécution de la requête KQL...")

        # 5. Traiter par batches
        total_processed = 0
        batch_size = config.batch_size
        skip = 0
        batch_number = 1

        while True:
            # Construire la requête avec pagination
            batch_query = f"{kql_query} | skip {skip} | take {batch_size}"

            logger.info(f"Traitement du batch {batch_number} (skip: {skip})...")

            # Récupérer le batch
            logs = source_client.query_logs(batch_query)

            if not logs:
                logger.info("Aucun log supplémentaire à traiter")
                break

            logger.info(f"Batch {batch_number}: {len(logs)} logs récupérés")

            # Envoyer au destination
            try:
                dest_client.send_logs(logs)
                total_processed += len(logs)
                logger.info(
                    f"Batch {batch_number} envoyé avec succès "
                    f"(total: {total_processed} logs)"
                )
            except Exception as e:
                logger.error(
                    f"Erreur lors de l'envoi du batch {batch_number}: {str(e)}"
                )
                # Continuer avec le prochain batch
                pass

            # Incrémenter pour le prochain batch
            skip += batch_size
            batch_number += 1

            # Si moins que batch_size, c'est le dernier batch
            if len(logs) < batch_size:
                logger.info("Dernier batch traité")
                break

            # Sécurité: limiter à 100 batches (500K logs)
            if batch_number > 100:
                logger.warning("Limite de 100 batches atteinte, arrêt du traitement")
                break

        # 6. Mettre à jour le checkpoint
        logger.info("Mise à jour du checkpoint...")
        checkpoint_mgr.update_checkpoint(
            timestamp=current_time, records_processed=total_processed, status="success"
        )

        # 7. Résumé final
        duration = (
            datetime.utcnow() - datetime.fromisoformat(utc_timestamp)
        ).total_seconds()
        logger.info(
            f"=== Traitement terminé avec succès ==="
            f"\n  - Période: {last_checkpoint.isoformat()} à {current_time.isoformat()}"
            f"\n  - Logs transférés: {total_processed}"
            f"\n  - Batches traités: {batch_number - 1}"
            f"\n  - Durée: {duration:.2f}s"
        )

    except Exception as e:
        error_msg = f"Erreur critique lors du traitement: {str(e)}"
        logger.error(error_msg)
        logger.error(traceback.format_exc())

        # Tenter de logger l'erreur dans le checkpoint
        try:
            checkpoint_mgr.update_checkpoint(
                timestamp=datetime.utcnow(),
                records_processed=0,
                status="error",
                error_message=str(e),
            )
        except:
            pass

        # Re-lever l'exception pour que Azure Functions la capture
        raise
